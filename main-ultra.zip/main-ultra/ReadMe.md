step:
1. git clone https://github.com/Hhhusvdjwhsh/Ubot userbot
- username : Hhhusvdjwhsh
- pass : 

2. sudo apt update && sudo apt upgrade -y
3. sudo apt install python3.10-venv ffmpeg
4. cd userbot
5. screen -S userbot
6. python3 -m venv userbot
7. source userbot/bin/activate
8. pip install -r requirements.txt
9. cp sample.env .env
10. nano .env (isi varsnya, ctrl + s buat save, ctrl + x buat exit nano)
11. bash start
